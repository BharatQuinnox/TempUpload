﻿using Demo.Dto;
using Demo.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Web;

namespace Demo.Services
{
    public class CustomerService : ICustomerService
    {
        public List<Customers> GetAllCustomers()
        {
           return getCustomers();
        }

        public Customers GetCustomerById(int Id)
        {
           return getCustomers().Where(x => x.Id == Id).FirstOrDefault() ;
        }

        private List<Customers> getCustomers()
        {
            List<Customers> dummyCustomers = new List<Customers>
        {
            new Customers { Id = 1, Name = "John Doe", Country = "USA", City = "New York" },
            new Customers { Id = 2, Name = "Jane Smith", Country = "Canada", City = "Toronto" },
            new Customers { Id = 3, Name = "Bob Johnson", Country = "UK", City = "London" }
         };

            return dummyCustomers;
        }
    }
}