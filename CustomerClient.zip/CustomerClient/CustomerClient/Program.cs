﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerClient.CustomerService;

namespace CustomerClient
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Get All Customers
            CustomerServiceClient customerServiceClient = new CustomerServiceClient();
            var result = customerServiceClient.GetAllCustomers();
            
            //Get Customerby ID
            var Customer = customerServiceClient.GetCustomerById(1);
            Console.Read();
        }
    }
}
